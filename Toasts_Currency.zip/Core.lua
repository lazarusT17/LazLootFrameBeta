-- Core.lua (Retail 120001-safe: no CHAT_MSG_CURRENCY parsing)
local ADDON, NS = ...

local f = CreateFrame("Frame")

-- =========================================================
-- State
-- =========================================================

local lootSlots = {}          -- [slot] = { link, quantity, slotType }
local pending = {}            -- [key] = { itemLink, quantity }

local prevMoney = nil         -- integer copper
local prevCurrency = {}       -- [currencyID] = quantity

-- =========================================================
-- Helpers
-- =========================================================

local function HexToRGB(hex)
  if not hex or #hex < 6 then return 1, 1, 1 end
  local r = tonumber(hex:sub(1,2), 16) or 255
  local g = tonumber(hex:sub(3,4), 16) or 255
  local b = tonumber(hex:sub(5,6), 16) or 255
  return r/255, g/255, b/255
end

local function ExtractNameFromLink(link)
  if not link then return "" end
  return link:match("%[(.-)%]") or ""
end

local function GetFastItemIcon(itemID)
  if not itemID then return nil end
  if C_Item and C_Item.GetItemIconByID then
    local ok, icon = pcall(C_Item.GetItemIconByID, itemID)
    if ok and icon then return icon end
  end
  if GetItemInfoInstant then
    local _, _, _, _, icon = GetItemInfoInstant(itemID)
    return icon
  end
  return nil
end

local function GetQualityDuration(quality)
  local db = NS.DB
  if not db or not db.durations then return 3 end
  if quality == 0 then return db.durations.poor end
  if quality == 1 then return db.durations.common end
  if quality == 2 then return db.durations.uncommon end
  if quality == 3 then return db.durations.rare end
  if quality == 4 then return db.durations.epic end
  if quality == 5 then return db.durations.legendary end
  return db.durations.common
end

local function IsBlacklisted(itemID)
  local db = NS.DB
  if not db or not db.blacklist or not db.blacklist.enabled then return false end
  return db.blacklist.items and db.blacklist.items[itemID] == true
end

-- Auctionator unit price (optional)
local function GetAuctionatorUnitPrice(itemLink, itemID)
  if not Auctionator or not Auctionator.API or not Auctionator.API.v1 then return 0 end

  if itemID then
    local ok, v = pcall(Auctionator.API.v1.GetAuctionPriceByItemID, ADDON, itemID)
    if ok and type(v) == "number" then return v end
  end

  if itemLink then
    local ok, v = pcall(Auctionator.API.v1.GetAuctionPriceByItemLink, ADDON, itemLink)
    if ok and type(v) == "number" then return v end
  end

  return 0
end

local function CopperToGSC(copper)
  copper = tonumber(copper) or 0
  local g = math.floor(copper / 10000); copper = copper - g * 10000
  local s = math.floor(copper / 100);   copper = copper - s * 100
  local c = copper
  return g, s, c
end

local function FormatMoneyColored(copper, digitsHex)
  local g, s, c = CopperToGSC(copper)
  local digits = digitsHex or "ffffffff"
  return string.format(
    "|cff%s%d|r |cffffd700g|r |cff%s%d|r |cffc7c7cfs|r |cff%s%d|r |cffeda55fc|r",
    digits, g, digits, s, digits, c
  )
end

local function BuildPriceText(unitCopper, stackCopper, quantity)
  local db = NS.DB
  if not db or not db.price or (not db.price.showAH and not db.price.showStack) then return "" end

  local vendorUnit = 0
  local sellPrice = select(11, GetItemInfo(quantity and quantity.itemLink or nil))
  if type(sellPrice) == "number" and sellPrice > 0 then vendorUnit = sellPrice end

  local unitText, stackText = "", ""
  if unitCopper and unitCopper > 0 then
    unitText = FormatMoneyColored(unitCopper, "ffffffff")
  end
  if stackCopper and stackCopper > 0 then
    stackText = FormatMoneyColored(stackCopper, "ffffffff")
  end

  if db.price.replaceSingleWithStack and quantity and quantity > 1 then
    if db.price.showStack and stackText ~= "" then
      if db.price.showAH and unitText ~= "" then
        return stackText .. "\n" .. unitText
      end
      return stackText
    end
  end

  local parts = {}
  if db.price.showAH and unitText ~= "" then table.insert(parts, unitText) end
  if db.price.showStack and stackText ~= "" then table.insert(parts, stackText) end

  if #parts == 0 then return "" end
  if #parts == 1 then return parts[1] end
  return parts[2] .. "\n" .. parts[1]
end

-- =========================================================
-- Item Toasts (loot-slot driven)
-- =========================================================

local function ShowItemToastFast(itemLink, quantity)
  quantity = tonumber(quantity) or 1
  if not itemLink then return end

  local itemID = tonumber(itemLink:match("item:(%d+)"))
  if itemID and IsBlacklisted(itemID) then return end

  local name = ExtractNameFromLink(itemLink)
  if name == "" then name = itemLink end

  local quality = (C_Item and C_Item.GetItemQualityByID) and C_Item.GetItemQualityByID(itemID) or nil
  local r, g, b
  if quality ~= nil then
    r, g, b = GetItemQualityColor(quality)
  else
    local hex = itemLink:match("|cff(%x%x%x%x%x%x)")
    r, g, b = HexToRGB(hex)
    quality = 1
  end

  local icon = GetFastItemIcon(itemID)
  local dur = GetQualityDuration(quality)

  -- Auctionator price
  local unitCopper = GetAuctionatorUnitPrice(itemLink, itemID) or 0
  local stackCopper = unitCopper * quantity
  local priceText = BuildPriceText(unitCopper, stackCopper, quantity)

  NS.Toast:ShowToast({
    icon = icon,
    name = name .. (quantity > 1 and (" x" .. quantity) or ""),
    nameR = r, nameG = g, nameB = b,
    rightText = priceText, -- NOTE: your Toasts_Core uses rightText, not priceText
    duration = dur,
  })
end

-- If you still want GET_ITEM_INFO_RECEIVED delayed resolves, keep this:
local function HandlePendingItemInfo()
  for key, p in pairs(pending) do
    if p.itemLink then
      local name = GetItemInfo(p.itemLink)
      if name then
        pending[key] = nil
        ShowItemToastFast(p.itemLink, p.quantity)
      end
    end
  end
end

-- =========================================================
-- Loot slot capture
-- =========================================================

local function handleLootReady()
  local numSlots = GetNumLootItems()
  if not numSlots or numSlots <= 0 then return end

  for slot = 1, numSlots do
    local link = GetLootSlotLink(slot)
    if link then
      local _, _, quantity = GetLootSlotInfo(slot)
      lootSlots[slot] = {
        link = link,
        quantity = quantity or 1,
        slotType = GetLootSlotType(slot),
      }
    end
  end
end

local function handleLootSlotCleared(slot)
  local data = lootSlots[slot]
  if not data then return end
  lootSlots[slot] = nil

  if data.slotType == LOOT_SLOT_ITEM then
    ShowItemToastFast(data.link, data.quantity)

  elseif data.slotType == LOOT_SLOT_CURRENCY then
    -- Currency toast delta will be handled by CURRENCY_DISPLAY_UPDATE.
    -- We do NOTHING here on purpose.

  elseif data.slotType == LOOT_SLOT_MONEY then
    -- Money delta will be handled by PLAYER_MONEY.
    -- We do NOTHING here on purpose.
  end
end

-- =========================================================
-- Currency tracking (NO CHAT PARSING)
-- =========================================================

local function SnapshotAllCurrencies()
  if not C_CurrencyInfo or not C_CurrencyInfo.GetCurrencyListSize or not C_CurrencyInfo.GetCurrencyListInfo then return end
  local n = C_CurrencyInfo.GetCurrencyListSize() or 0
  for i = 1, n do
    local info = C_CurrencyInfo.GetCurrencyListInfo(i)
    if info and info.currencyID and info.name and not info.isHeader then
      -- Use GetCurrencyInfo to ensure quantity/max are current
      local full = C_CurrencyInfo.GetCurrencyInfo(info.currencyID)
      if full then
        prevCurrency[info.currencyID] = full.quantity or 0
      end
    end
  end
end

local function HandleCurrencyUpdate(currencyID)
  if not C_CurrencyInfo or not C_CurrencyInfo.GetCurrencyInfo then return end

  local function processOne(id)
    local info = C_CurrencyInfo.GetCurrencyInfo(id)
    if not info then return end

    local newQty = info.quantity or 0
    local oldQty = prevCurrency[id]

    -- Initialize without toasting if we've never seen it
    if oldQty == nil then
      prevCurrency[id] = newQty
      return
    end

    local delta = newQty - oldQty
    prevCurrency[id] = newQty

    if delta > 0 then
      NS.Toast:UpsertCurrencyToast(
        id,
        info.name or ("Currency " .. tostring(id)),
        info.iconFileID,
        delta,
        newQty,
        info.maxQuantity,
        false,
        (NS.DB and NS.DB.durations and NS.DB.durations.currency) or 15
      )
    end
  end

  if currencyID then
    processOne(currencyID)
  else
    -- bulk update
    if not C_CurrencyInfo.GetCurrencyListSize then return end
    local n = C_CurrencyInfo.GetCurrencyListSize() or 0
    for i = 1, n do
      local li = C_CurrencyInfo.GetCurrencyListInfo(i)
      if li and li.currencyID and not li.isHeader then
        processOne(li.currencyID)
      end
    end
  end
end

-- =========================================================
-- Money tracking (NO CHAT PARSING) - upsert
-- =========================================================

local function HandleMoneyUpdate()
  local newMoney = GetMoney() or 0

  if prevMoney == nil then
    prevMoney = newMoney
    return
  end

  local delta = newMoney - prevMoney
  prevMoney = newMoney

  if delta > 0 then
    -- If your function is named differently, change this line:
    if NS.Toast and NS.Toast.UpsertMoneyToast then
      NS.Toast:UpsertMoneyToast(delta, newMoney, (NS.DB and NS.DB.durations and NS.DB.durations.gold) or 10)
    elseif NS.Toast and NS.Toast.ShowMoneyToast then
      -- fallback if you haven’t renamed it yet
      NS.Toast:ShowMoneyToast(delta, (NS.DB and NS.DB.durations and NS.DB.durations.gold) or 10)
    end
  end
end

-- =========================================================
-- Slash: /llf opens options (Retail-safe)
-- =========================================================

local function OpenOptions()
  if Settings and Settings.OpenToCategory then
    Settings.OpenToCategory("LazLootFrame")
    Settings.OpenToCategory("LazLootFrame")
  elseif InterfaceOptionsFrame_OpenToCategory then
    InterfaceOptionsFrame_OpenToCategory("LazLootFrame")
    InterfaceOptionsFrame_OpenToCategory("LazLootFrame")
  end
end

SLASH_LAZLOOTFRAME1 = "/llf"
SlashCmdList.LAZLOOTFRAME = OpenOptions

-- =========================================================
-- Events
-- =========================================================

f:SetScript("OnEvent", function(_, event, ...)
  if event == "ADDON_LOADED" then
    local name = ...
    if name ~= ADDON then return end

    NS:InitDB()
    if NS.BuildOptions then NS:BuildOptions() end

    -- Snapshot baselines
    prevMoney = GetMoney() or 0
    SnapshotAllCurrencies()

    -- Loot
    f:RegisterEvent("LOOT_READY")
    f:RegisterEvent("LOOT_SLOT_CLEARED")
    f:RegisterEvent("LOOT_ITEM_ROLL_WON")

    -- Money / Currency (SAFE)
    f:RegisterEvent("PLAYER_MONEY")
    f:RegisterEvent("CURRENCY_DISPLAY_UPDATE")

    -- Item info resolve
    f:RegisterEvent("GET_ITEM_INFO_RECEIVED")

    -- You can add reputation tracking later via UPDATE_FACTION (preferred)
    return
  end

  if not NS.DB then return end

  if event == "LOOT_READY" then
    handleLootReady()

  elseif event == "LOOT_SLOT_CLEARED" then
    local slot = ...
    handleLootSlotCleared(slot)

  elseif event == "LOOT_ITEM_ROLL_WON" then
    local itemLink, rollQuantity, _, _, _, rollerId = ...
    if itemLink and rollerId == UnitGUID("player") then
      ShowItemToastFast(itemLink, rollQuantity or 1)
    end

  elseif event == "PLAYER_MONEY" then
    HandleMoneyUpdate()

  elseif event == "CURRENCY_DISPLAY_UPDATE" then
    local currencyID = ...
    HandleCurrencyUpdate(currencyID)

  elseif event == "GET_ITEM_INFO_RECEIVED" then
    HandlePendingItemInfo()
  end
end)

f:RegisterEvent("ADDON_LOADED")