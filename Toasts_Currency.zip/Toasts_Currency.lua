-- Toasts_Currency.lua
local ADDON, NS = ...
local Core = NS.ToastCore
local Toast = NS.Toast

local function CurrencyRightText(gained, total, maxQty, r, g, b)
  gained = tonumber(gained) or 0

  local WHITE = "|cffffffff"
  local NAME_COLOR = Core.RGBToHex(r, g, b)

  local line1 = WHITE .. "x" .. gained .. "|r"

  if total ~= nil then
    total = tonumber(total) or 0
    maxQty = tonumber(maxQty) or 0

    if maxQty > 0 then
      return line1 .. "\n"
        .. NAME_COLOR .. total .. "|r"
        .. WHITE .. "/" .. maxQty .. "|r"
    else
      return line1 .. "\n"
        .. NAME_COLOR .. total .. "|r"
    end
  end

  return line1
end

function Toast:UpsertCurrencyToast(currencyID, currencyName, icon, gained, total, maxQty, _, duration)
  if not currencyID then return end

  local key = "currency:" .. tostring(currencyID)
  local existing = Core.byKey[key]
  duration = duration or (NS.DB and NS.DB.durations and NS.DB.durations.currency) or 15

  local nameR, nameG, nameB = 1.0, 0.82, 0.0

  if existing and existing._inUse then
    existing._currencyGained = (tonumber(existing._currencyGained) or 0) + (tonumber(gained) or 0)
    if total ~= nil then existing._currencyTotal = tonumber(total) end
    if maxQty ~= nil then existing._currencyMax = tonumber(maxQty) end

    Core:UpdateInPlace(existing, {
      icon = icon,
      name = currencyName,
      nameR = nameR, nameG = nameG, nameB = nameB,
      rightText = CurrencyRightText(existing._currencyGained, existing._currencyTotal, existing._currencyMax, nameR, nameG, nameB),
    })

    return existing
  end

  local f = Core:ShowToast({
    key = key,
    icon = icon,
    name = currencyName,
    nameR = nameR, nameG = nameG, nameB = nameB,
    rightText = CurrencyRightText(gained, total, maxQty, nameR, nameG, nameB),
    duration = duration,
  })

  f._currencyGained = tonumber(gained) or 0
  f._currencyTotal = (total ~= nil) and tonumber(total) or nil
  f._currencyMax   = (maxQty ~= nil) and tonumber(maxQty) or nil

  return f
end