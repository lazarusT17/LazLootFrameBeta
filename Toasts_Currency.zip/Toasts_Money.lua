-- Toasts_Money.lua
local ADDON, NS = ...
local Core = NS.ToastCore
local Toast = NS.Toast

local function CopperToGSC(copper)
  copper = tonumber(copper) or 0
  local g = math.floor(copper / 10000); copper = copper - g * 10000
  local s = math.floor(copper / 100);   copper = copper - s * 100
  local c = copper
  return g, s, c
end

local function MoneyLineText(copper, colorHex)
  local g, s, c = CopperToGSC(copper)
  local col = colorHex or "|cffffffff"
  return string.format(
    "%s%d|r |cffffd700g|r %s%d|r |cffc7c7cfs|r %s%d|r |cffeda55fc|r",
    col, g, col, s, col, c
  )
end

-- right column:
-- line1 (gained) white
-- line2 (total) colored to match name color
local function MoneyRightText(gainedCopper, totalCopper, nameR, nameG, nameB)
  local WHITE = "|cffffffff"
  local NAME_COLOR = Core.RGBToHex(nameR, nameG, nameB)
  local line1 = MoneyLineText(gainedCopper, WHITE)
  if totalCopper ~= nil then
    return line1 .. "\n" .. MoneyLineText(totalCopper, NAME_COLOR)
  end
  return line1
end

-- Call this from Core.lua when you detect money delta (you likely already do)
function Toast:UpsertMoneyToast(gainedCopper, totalCopper, duration)
  gainedCopper = tonumber(gainedCopper) or 0
  totalCopper = (totalCopper ~= nil) and tonumber(totalCopper) or nil
  duration = duration or 10

  local key = "money"
  local existing = Core.byKey[key]
  local nameR, nameG, nameB = 1, 1, 1

  if existing and existing._inUse then
    existing._moneyGained = (tonumber(existing._moneyGained) or 0) + gainedCopper
    if totalCopper ~= nil then existing._moneyTotal = totalCopper end

    Core:UpdateInPlace(existing, {
      icon = 133784, -- coin
      name = "Money",
      nameR = nameR, nameG = nameG, nameB = nameB,
      rightText = MoneyRightText(existing._moneyGained, existing._moneyTotal, nameR, nameG, nameB),
    })

    return existing
  end

  local f = Core:ShowToast({
    key = key,
    icon = 133784,
    name = "Money",
    nameR = nameR, nameG = nameG, nameB = nameB,
    rightText = MoneyRightText(gainedCopper, totalCopper, nameR, nameG, nameB),
    duration = duration,
  })

  f._moneyGained = gainedCopper
  f._moneyTotal  = totalCopper

  return f
end