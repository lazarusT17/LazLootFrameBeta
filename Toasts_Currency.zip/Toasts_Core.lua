-- Toasts_Core.lua
local ADDON, NS = ...

NS.ToastCore = NS.ToastCore or {}
local Core = NS.ToastCore

NS.Toast = NS.Toast or {} -- public API table for modules to attach functions to

Core.active = Core.active or {}
Core.pool   = Core.pool   or {}
Core.byKey  = Core.byKey  or {}

local ICON_SIZE = 38

local function Clamp(v, a, b)
  if v < a then return a end
  if v > b then return b end
  return v
end

function Core.RGBToHex(r, g, b)
  r = math.floor((r or 1) * 255 + 0.5)
  g = math.floor((g or 1) * 255 + 0.5)
  b = math.floor((b or 1) * 255 + 0.5)
  return string.format("|cff%02x%02x%02x", r, g, b)
end

local function CreateToastFrame()
  local f = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
  f:SetFrameStrata("HIGH")
  f:SetClampedToScreen(true)
  f:SetAlpha(0)
  f:Hide()

  f.bg = f:CreateTexture(nil, "BACKGROUND")
  f.bg:SetAllPoints(true)
  f.bg:SetColorTexture(0, 0, 0, 0.55)

  f.border = CreateFrame("Frame", nil, f, "BackdropTemplate")
  f.border:SetAllPoints(true)
  f.border:SetBackdrop({
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    edgeSize = 12,
  })
  f.border:SetBackdropBorderColor(1, 1, 1, 0.35)

  -- layout constants (matching your current look)
  f._padL = 6
  f._padR = 14
  f._padT = 8
  f._padB = 8
  f._gap  = 12

  -- icon top-left
  f.icon = f:CreateTexture(nil, "ARTWORK")
  f.icon:SetSize(ICON_SIZE, ICON_SIZE)
  f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", f._padL, -f._padT)

  -- right column top-right (2 lines)
  f.right = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f.right:SetJustifyH("RIGHT")
  f.right:SetJustifyV("TOP")
  f.right:SetWordWrap(true)
  f.right:SetMaxLines(2)
  f.right:SetPoint("TOPRIGHT", f, "TOPRIGHT", -f._padR, -f._padT)

  -- left column top-left (2 lines), lowered a couple px
  f.left = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f.left:SetJustifyH("LEFT")
  f.left:SetJustifyV("TOP")
  f.left:SetWordWrap(true)
  f.left:SetMaxLines(2)
  f.left:SetPoint("TOPLEFT", f.icon, "TOPRIGHT", f._gap, -3)
  f.left:SetPoint("RIGHT", f.right, "LEFT", -f._gap, 0)

  -- measurer for right width
  f._measureRight = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f._measureRight:Hide()

  -- fade animation
  f.fadeGroup = f:CreateAnimationGroup()

  local fadeIn = f.fadeGroup:CreateAnimation("Alpha")
  fadeIn:SetFromAlpha(0); fadeIn:SetToAlpha(1)
  fadeIn:SetDuration(0.12); fadeIn:SetOrder(1)

  f.hold = f.fadeGroup:CreateAnimation("Alpha")
  f.hold:SetFromAlpha(1); f.hold:SetToAlpha(1)
  f.hold:SetDuration(1); f.hold:SetOrder(2)

  local fadeOut = f.fadeGroup:CreateAnimation("Alpha")
  fadeOut:SetFromAlpha(1); fadeOut:SetToAlpha(0)
  fadeOut:SetDuration(0.25); fadeOut:SetOrder(3)

  f.fadeGroup:SetScript("OnFinished", function()
    f:Hide()
    f:SetAlpha(0)
    f._inUse = false

    for i = #Core.active, 1, -1 do
      if Core.active[i] == f then
        table.remove(Core.active, i)
        break
      end
    end

    if f._key and Core.byKey[f._key] == f then
      Core.byKey[f._key] = nil
    end

    f._key = nil
    table.insert(Core.pool, f)
    Core:Reflow()
  end)

  return f
end

function Core:Get()
  local f = table.remove(self.pool)
  if not f then f = CreateToastFrame() end
  f._inUse = true
  return f
end

local function MeasureRightWidth(f, text)
  if not text or text == "" then return 0 end

  local maxW = 0
  for line in text:gmatch("([^\n]+)") do
    f._measureRight:SetText(line)
    local w = f._measureRight:GetStringWidth() or 0
    if w > maxW then maxW = w end
  end
  return Clamp(maxW + 6, 70, 220)
end

local function ApplyLayout(f)
  local db = NS.DB
  if not db then return end

  local width = Clamp(tonumber(db.width) or 520, 280, 900)
  f:SetWidth(width)

  local padL = f._padL
  local padR = f._padR
  local padT = f._padT
  local padB = f._padB
  local gap  = f._gap

  local hasRight = f._hasRight
  local rightW = 0
  if hasRight then rightW = MeasureRightWidth(f, f._rightText) end

  f.right:SetWidth(rightW)
  f.right:SetShown(hasRight)

  local leftW = width - (padL + ICON_SIZE + gap + gap + rightW + padR)
  if leftW < 80 then leftW = 80 end
  f.left:SetWidth(leftW)

  local leftH  = f.left:GetStringHeight() or 0
  local rightH = hasRight and (f.right:GetStringHeight() or 0) or 0
  local contentH = math.max(ICON_SIZE, leftH, rightH)

  local totalH = math.ceil(contentH + padT + padB)
  if totalH < 44 then totalH = 44 end
  f:SetHeight(totalH)
end

function Core:Reflow()
  local db = NS.DB
  if not db then return end

  local anchor = db.anchor
  local x = anchor.x or 0
  local y = anchor.y or 0
  local scale = tonumber(db.scale) or 1
  local gap = 8

  local offset = 0
  for _, f in ipairs(self.active) do
    ApplyLayout(f)
    f:SetScale(scale)

    f:ClearAllPoints()
    if anchor.grow == "DOWN" then
      f:SetPoint(anchor.point, UIParent, anchor.point, x, y - offset)
    else
      f:SetPoint(anchor.point, UIParent, anchor.point, x, y + offset)
    end

    offset = offset + (f:GetHeight() + gap) * scale
  end
end

function Core:ShowToast(payload)
  if not NS.DB then return end

  local f = self:Get()

  f._key = payload.key
  if f._key then self.byKey[f._key] = f end

  if payload.icon then
    f.icon:SetTexture(payload.icon)
    f.icon:Show()
  else
    f.icon:Hide()
  end

  f.left:SetTextColor(payload.nameR or 1, payload.nameG or 1, payload.nameB or 1)
  f.left:SetText(payload.name or "")

  local rightText = payload.rightText or ""
  f._rightText = rightText
  f._hasRight = (rightText ~= "")
  f.right:SetText(rightText)

  table.insert(self.active, 1, f)
  self:Reflow()

  f:Show()
  f:SetAlpha(0)
  f.fadeGroup:Stop()
  f.hold:SetDuration(payload.duration or 3)
  f.fadeGroup:Play()

  return f
end
-- Compatibility for existing Options.lua / older code
NS.Toast = NS.Toast or {}

-- Allow NS.Toast:Reflow() to keep working
function NS.Toast:Reflow()
  return Core:Reflow()
end

-- If Options references these:
NS.Toast.active = Core.active
NS.Toast.pool   = Core.pool
NS.Toast.byKey  = Core.byKey
function Core:UpdateInPlace(f, payload)
  if payload.icon ~= nil then
    if payload.icon then
      f.icon:SetTexture(payload.icon)
      f.icon:Show()
    else
      f.icon:Hide()
    end
  end

  if payload.name ~= nil then
    f.left:SetTextColor(payload.nameR or 1, payload.nameG or 1, payload.nameB or 1)
    f.left:SetText(payload.name or "")
  end

  if payload.rightText ~= nil then
    local rightText = payload.rightText or ""
    f._rightText = rightText
    f._hasRight = (rightText ~= "")
    f.right:SetText(rightText)
  end

  ApplyLayout(f)
  self:Reflow()
  f:Show()
  f:SetAlpha(1)
end