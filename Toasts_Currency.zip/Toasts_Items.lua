-- Toasts_Items.lua
local ADDON, NS = ...
local Core = NS.ToastCore
local Toast = NS.Toast

-- Expected input: itemLink + (optional) count + (optional) rightText already formatted
-- You can wire Auctionator here without touching currencies.
function Toast:ShowItemToast(itemLink, count, rightText, duration)
  if not itemLink then return end
  count = tonumber(count) or 1

  local name, _, quality, _, _, _, _, _, _, icon = GetItemInfo(itemLink)
  name = name or itemLink
  icon = icon or 134400

  local r, g, b = 1, 1, 1
  if quality then r, g, b = GetItemQualityColor(quality) end

  local leftName = (count > 1) and (name .. " x" .. count) or name
  duration = duration or 10

  -- Items are NOT upserted by default (you can add per-item keying later)
  return Core:ShowToast({
    icon = icon,
    name = leftName,
    nameR = r, nameG = g, nameB = b,
    rightText = rightText or "",
    duration = duration,
  })
end