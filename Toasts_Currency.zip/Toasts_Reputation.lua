-- Toasts_Reputation.lua
local ADDON, NS = ...
local Core = NS.ToastCore
local Toast = NS.Toast

local function RepRightText(gained, current, maxValue, r, g, b)
  gained = tonumber(gained) or 0

  local WHITE = "|cffffffff"
  local NAME_COLOR = Core.RGBToHex(r, g, b)

  local line1 = WHITE .. "+" .. gained .. "|r"

  if current ~= nil then
    current = tonumber(current) or 0
    maxValue = tonumber(maxValue) or 0
    if maxValue > 0 then
      return line1 .. "\n"
        .. NAME_COLOR .. current .. "|r"
        .. WHITE .. "/" .. maxValue .. "|r"
    else
      return line1 .. "\n" .. NAME_COLOR .. current .. "|r"
    end
  end

  return line1
end

function Toast:UpsertReputationToast(factionID, factionName, icon, gained, current, maxValue, duration)
  if not factionID then return end

  local key = "rep:" .. tostring(factionID)
  local existing = Core.byKey[key]
  duration = duration or 15

  -- choose your rep name color here (white by default)
  local nameR, nameG, nameB = 1, 1, 1

  if existing and existing._inUse then
    existing._repGained = (tonumber(existing._repGained) or 0) + (tonumber(gained) or 0)
    if current ~= nil then existing._repCurrent = tonumber(current) end
    if maxValue ~= nil then existing._repMax = tonumber(maxValue) end

    Core:UpdateInPlace(existing, {
      icon = icon,
      name = factionName,
      nameR = nameR, nameG = nameG, nameB = nameB,
      rightText = RepRightText(existing._repGained, existing._repCurrent, existing._repMax, nameR, nameG, nameB),
    })
    return existing
  end

  local f = Core:ShowToast({
    key = key,
    icon = icon,
    name = factionName,
    nameR = nameR, nameG = nameG, nameB = nameB,
    rightText = RepRightText(gained, current, maxValue, nameR, nameG, nameB),
    duration = duration,
  })

  f._repGained = tonumber(gained) or 0
  f._repCurrent = (current ~= nil) and tonumber(current) or nil
  f._repMax = (maxValue ~= nil) and tonumber(maxValue) or nil

  return f
end